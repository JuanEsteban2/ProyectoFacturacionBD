﻿namespace proyecto_final
{
    partial class clientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.texdate = new System.Windows.Forms.TextBox();
            this.texpreciot = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.texestado = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(349, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ventas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(90, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "fecha";
            // 
            // texdate
            // 
            this.texdate.Location = new System.Drawing.Point(90, 163);
            this.texdate.Name = "texdate";
            this.texdate.Size = new System.Drawing.Size(100, 23);
            this.texdate.TabIndex = 2;
            // 
            // texpreciot
            // 
            this.texpreciot.AutoSize = true;
            this.texpreciot.Location = new System.Drawing.Point(404, 145);
            this.texpreciot.Name = "texpreciot";
            this.texpreciot.Size = new System.Drawing.Size(67, 15);
            this.texpreciot.TabIndex = 3;
            this.texpreciot.Text = "precio total";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(404, 163);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 23);
            this.textBox2.TabIndex = 4;
            // 
            // texestado
            // 
            this.texestado.AutoSize = true;
            this.texestado.Location = new System.Drawing.Point(90, 243);
            this.texestado.Name = "texestado";
            this.texestado.Size = new System.Drawing.Size(42, 15);
            this.texestado.TabIndex = 5;
            this.texestado.Text = "estado";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(90, 261);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 23);
            this.textBox3.TabIndex = 6;
            // 
            // clientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.texestado);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.texpreciot);
            this.Controls.Add(this.texdate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "clientes";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox texdate;
        private Label texpreciot;
        private TextBox textBox2;
        private Label texestado;
        private TextBox textBox3;
    }
}