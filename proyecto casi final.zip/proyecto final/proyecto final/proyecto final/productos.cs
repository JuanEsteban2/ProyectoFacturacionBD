﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Capa_Logica;
using Clase_Presentacion;

namespace proyecto_final
{
    public partial class productos : Form
    {
        ClaseLogica objlog = new ClaseLogica();
        ClasePresentacion objpre = new ClasePresentacion();
        public productos()
        {
            InitializeComponent();
        }

        void mantenimiento(String accion)
        {
            objlog.id_producto = Convert.ToInt32(txtidproducto.Text);
            objlog.nombre_producto = txtnombre.Text;
            objlog.precio = Convert.ToInt32(txtprecio.Text);
            objlog.cantidad = Convert.ToInt32(txtcantidad.Text);
            objlog.id_proveedor1 = Convert.ToInt32(txtidproveedor.Text);
            String men = objpre.P_modificar_producto(objlog);
            MessageBox.Show(men, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        void limpiar ()
        {
            txtidproducto.Text = "";
            txtnombre.Text = "";
            txtprecio.Text = "";
            txtcantidad.Text = "";
            txtidproveedor.Text = "";
            dataGridView1.DataSource = objpre.P_listar_productos;
        }

        private void productos_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = objpre.P_listar_productos;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
